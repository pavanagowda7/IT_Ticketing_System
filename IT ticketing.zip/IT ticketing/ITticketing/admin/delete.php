<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
 // for  password change   
if(isset($_POST['deleteTicket']))
{
$tid=$_POST['deleteTicket']; 


if(mysqli_query($con,"DELETE FROM TICKETS WHERE TICKETID='$tid' "))
{

echo "<script>alert('Ticket Deleted!!');</script>";
echo "<script type='text/javascript'> document.location = 'viewTickets.php'; </script>";
}
else
{
echo "<script>alert('Unable to Delete !!');</script>";
echo "<script type='text/javascript'> document.location = 'viewTickets.php''; </script>";
}
}

    
} ?>
