<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
 // for  password change   
if(isset($_POST['update']))
{
$tid=$_POST['id']; 
$status=$_POST['status'];
$comment=$_POST['comment'];
$sql="UPDATE TICKETS SET STATUS='$status',AdminComment='$comment' WHERE TICKETID='$tid'";
if(mysqli_query($con,$sql))
{

echo "<script>alert('Status Updated !!');</script>";
echo "<script type='text/javascript'> document.location = 'viewTickets.php'; </script>";
}
else
{
echo "<script>alert('Status not Updated !!');</script>";
echo "<script type='text/javascript'> document.location = 'viewTickets.php''; </script>";
}
}

    
} ?>
